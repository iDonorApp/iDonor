package com.example.ababab;

import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.AsyncTask;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.tensorflow.lite.Interpreter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {




        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                // Load the TFLite model
                try {
                        tflite = new Interpreter(loadModelFile());
                } catch (IOException e) {
                        e.printStackTrace();
                }

                // Initialize the views
                resultTextView = findViewById(R.id.result_text_view);
                Spinner bloodTypeSpinner = findViewById(R.id.blood_type_spinner);
                Button predictButton = findViewById(R.id.predict_button);

                // Set up the blood type dropdown
                String[] bloodTypes = getResources().getStringArray(R.array.blood_types);
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_item, bloodTypes);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                bloodTypeSpinner.setAdapter(adapter);

                // Set up the predict button click listener
                predictButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                                String selectedBloodType = bloodTypeSpinner.getSelectedItem().toString();
                                performPrediction(selectedBloodType);
                        }
                });

                // Fetch data from API and prepare sample data
                new GetDataTask().execute();
        }

        private void performPrediction(String bloodType) {
                // Process the input data
                float[][] input = preprocessInput(bloodType);

                // Prepare the output array
                float[][] output = new float[OUTPUT_SIZE][1];

                // Run inference
                tflite.run(input, output);

                // Process the output data
                List<Person> filteredList = postprocessOutput(output, bloodType);

                // Display the filtered data
                StringBuilder result = new StringBuilder();
                for (int i = 0; i < filteredList.size(); i++) {
                        Person person = filteredList.get(i);
                        result.append("Name: ").append(person.getName()).append(", Age: ").append(person.getAge()).append("\n");
                }
                if (result.length() == 0) {
                        result.append("No matching records found for blood type ").append(bloodType);
                }
                resultTextView.setText(result.toString());
        }

        private float[][] preprocessInput(String bloodType) {
                float[][] input = new float[1][INPUT_SIZE];
                char c = bloodType.charAt(0);
                input[0][0] = c - 'A' + 1;
                return input;
        }

        private List<Person> postprocessOutput(float[][] output, String bloodType) {
                // Filter the people list based on the predicted output
                List<Person> filteredList = new ArrayList<>();
                int predictedLabel = Math.round(output[0][0]);
                if (predictedLabel == 1) {
                        for (int j = 0; j < peopleList.size(); j++) {
                                Person person = peopleList.get(j);
                                if (person.getBloodType().equals(bloodType)) {
                                        filteredList.add(person);
                                }
                        }
                }
                return filteredList;
        }

        private MappedByteBuffer loadModelFile() throws IOException {
                AssetFileDescriptor fileDescriptor = getAssets().openFd(MODEL_PATH);
                FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
                FileChannel fileChannel = inputStream.getChannel();
                long startOffset = fileDescriptor.getStartOffset();
                long declaredLength = fileDescriptor.getDeclaredLength();
                return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
        }

        private class GetDataTask extends AsyncTask<Void, Void, List<Person>> {
                @Override
                protected List<Person> doInBackground(Void... voids) {
                        List<Person> dataList = new ArrayList<>();

                        return dataList;
                }

                @Override
                protected void onPostExecute(List<Person> dataList) {
                        if (dataList != null) {
                                peopleList = dataList;

                                // Data preparation is complete, continue with UI setup or other operations
                                // For example, initialize the spinner selection
                                Spinner bloodTypeSpinner = findViewById(R.id.blood_type_spinner);
                                bloodTypeSpinner.setSelection(0);

                                // Perform default prediction after data is available
                                String selectedBloodType = bloodTypeSpinner.getSelectedItem().toString();
                                performPrediction(selectedBloodType);
                        } else {
                                // Handle the case when dataList is null (API request failed or returned empty data)
                                // You can display an error message or take appropriate action
                        }
                }
        }

        private class Person {
                private String name;
                private int age;
                private String bloodType;

                public Person(String name, int age, String bloodType) {
                        this.name = name;
                        this.age = age;
                        this.bloodType = bloodType;
                }

                public String getName() {
                        return name;
                }

                public int getAge() {
                        return age;
                }

                public String getBloodType() {
                        return bloodType;
                }
        }
}
